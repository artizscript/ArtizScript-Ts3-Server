insert into channel_properties ( server_id, id, ident, value) 
           values( :server_id:, :channel_id*:, :ident*:, :value*:)
 [[[ , (:server_id:, :channel_id*:, :ident*:, :value*:) ]]] ;